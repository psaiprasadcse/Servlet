
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;


public class del extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
try{

          //loading drivers for mysql
         Class.forName("com.mysql.jdbc.Driver");

 	 //creating connection with the database 
         Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Studentdb","root","");
         
         Statement st=con.createStatement();

		String r1 =request.getParameter("r");
		

	String q="delete from sreg where rollno='"+r1+"'";
 	
	st.executeUpdate(q);
	out.println("Deleted");
out.print("<a href='index.html'>Back</a>");
              
	}
catch (SQLException e) {
 
   e.printStackTrace();
  }
catch(Exception e)
    	  {
          e.printStackTrace();
      	}

		
		out.close();
	}

}
