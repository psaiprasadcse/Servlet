
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;


public class sel extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
 

try{

         Class.forName("com.mysql.jdbc.Driver");
 
   Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Studentdb","root","");
   Statement st=con.createStatement();

    ResultSet rs = st.executeQuery("select * from sreg");   
 
   out.println("<html><body><h2>The Select query has following results : </h2>");
   out.println("<hr></br><table cellspacing='0' cellpadding='5' border='1'>");
   out.println("<tr>");
   out.println("<td><b>Roll No</b></td>");
   out.println("<td><b>Name</b></td>");
   out.println("<td><b>Email</b></td>");
   out.println("<td><b>Mobile No</b></td>");
   out.println("</tr>");
 
   while(rs.next()) {
    out.println("<tr>");
    out.println("<td>"+rs.getString(1) + "</td>");
    out.println("<td>"+rs.getString(2) + "</td>");
    out.println("<td>"+rs.getString(3) + "</td>");
 out.println("<td>"+rs.getString(4) + "</td>");
    out.println("</tr>");
 
   }
 
   out.println("</table></br><hr></body></html>");
out.print("<a href='index.html'>Back</a>");
  }
  catch (SQLException e) {
 
   e.printStackTrace();
  }
catch(Exception e) {
         //Handle errors for Class.forName
         e.printStackTrace();
      } 
   
 }
 
}

