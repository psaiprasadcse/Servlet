
/*
[root@localhost ~]# service mysqld start
Redirecting to /bin/systemctl start  mysqld.service
[root@localhost ~]# mysql -u root
Welcome to the MariaDB monitor.  Commands end with ; or \g.
Your MariaDB connection id is 2
Server version: 5.5.33a-MariaDB MariaDB Server

Copyright (c) 2000, 2013, Oracle, Monty Program Ab and others.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

MariaDB [(none)]> create database Studentdb
    -> ;
Query OK, 1 row affected (0.00 sec)

MariaDB [Studentdb]> create table sreg (rollno char(2), name varchar(20), email varchar(25), mobile varchar(12));


*/
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;


public class ins extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
try{

          //loading drivers for mysql
         Class.forName("com.mysql.jdbc.Driver");

 	 //creating connection with the database 
         Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Studentdb","root","");
         
         Statement st=con.createStatement();

		String r1 =request.getParameter("r");
		String n1=request.getParameter("n");
		String e1=request.getParameter("e");
		String m1=request.getParameter("m");

	      out.println("Welcome:" +r1);
	      out.println("Your Email IS:"+e1);
	      out.println("Your Mobile No IS:"+m1);

	String q="insert into sreg values('"+r1+"','"+n1+"','"+e1+"','"+m1+"')";
 	out.println("Welcome:" +q);
	st.executeUpdate(q);
	out.println("Inserted");
out.print("<a href='index.html'>Back</a>");  
              
	}

catch (SQLException e) {
 
   e.printStackTrace();
  }
catch(Exception e)
    	  {
          e.printStackTrace();
      	}

		
		out.close();
	}

}
